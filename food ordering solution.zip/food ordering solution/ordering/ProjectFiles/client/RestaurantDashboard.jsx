import React from 'react';

const RestaurantDashboard = () => {
  return (
    <div>
      <h1>Restaurant Dashboard</h1>
    </div>
  );
};

export default RestaurantDashboard;
