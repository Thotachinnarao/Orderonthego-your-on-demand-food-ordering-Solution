import React from 'react';

const AddRestaurant = () => {
  return (
    <div>
      <h1>Add Restaurant Page</h1>
    </div>
  );
};

export default AddRestaurant;
