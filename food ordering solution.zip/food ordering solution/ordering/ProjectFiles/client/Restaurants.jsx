import React from 'react';

const Restaurants = () => {
  return (
    <div>
      <h1>Restaurants Page</h1>
    </div>
  );
};

export default Restaurants;
