import React from 'react';

const Menu = () => {
  return (
    <div>
      <h1>Menu Page</h1>
    </div>
  );
};

export default Menu;
